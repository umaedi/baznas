
<?php $__env->startSection('content'); ?>
<div class="main-content container">
    <section class="section">
      <div class="section-header">
        <h1><?php echo e(__("Detail Zakat")); ?></h1>
        <div class="section-header-breadcrumb">
          <div class="breadcrumb-item active"><a href="<?php echo e(route('muzakki.dashboard')); ?>">Dashboard</a></div>
          <div class="breadcrumb-item">Detail Zakat</div>
        </div>
      </div>
      <div class="card">
        <div id="x-message"></div>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="card-body">
            <div class="section-body">
                <h2 class="section-title">Detail Zakat</h2>
                <p class="section-lead">
                  Ini adalah detail zakat <?php echo e($invoice->muzakki->name); ?>, silakan dicek, klik konfirmasi unutk menerima atau tolak untuk menolak
                </p>
                <hr>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" value="<?php echo e($invoice->muzakki->name); ?>" readonly/>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" value="<?php echo e($invoice->muzakki->email); ?>" readonly/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">No HP</label>
                        <input type="text" class="form-control"  id="name" value="<?php echo e($invoice->muzakki->no_tlp); ?>" readonly/>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="email">Status</label>
                        <input type="email" class="form-control" id="email" value="<?php echo e($invoice->muzakki->dinas->nama_dinas); ?>" readonly/>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputState">ZIS(Zakat, Infaq, Shodaqoh)</label>
                        <input type="email" class="form-control" id="email" value="<?php echo e($invoice->category->nama_kategori); ?>" readonly/>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="name">Jumlah/Nominal</label>
                        <input type="text" name="nominal" class="form-control" value="<?php echo e($invoice->nominal); ?>" readonly/>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="name">Struk</label>
                        <div class="text-center">
                            <a href="<?php echo e(asset('storage/image/struk/'.$invoice->struk)); ?>" target="_blank" class="form-control btn-primary">Lihat Struk</a>
                        </div>
                    </div>
                    <div class="form-group col-md-12">
                    <form action="/amil/konfirmasi_zakat/<?php echo e($invoice->id); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
                            <label for="name">Pilih Kwitansi Jika Anda ingin mengkorimasi data ini</label>
                            <input type="file" name="kwitansi" class="form-control" required>    
                        </div>
                </div>        
                <a href="<?php echo e(route('amil.dashboard')); ?>" class="btn btn-primary btn-icon icon-left"><i class="fa fa-arrow-left"></i></a>
                        <button type="submit" class="btn btn-primary" id="confirm">KONFIRMASI</button>        
                    </form>       
                <button class="btn btn-warning" id="tolak"  onclick="return confirm('Yakin tolak data ini?')">TOLAK</button>               
                <a href="https://api.whatsapp.com/send?phone=<?php echo e($invoice->muzakki->no_tlp); ?>" target="_blank" class="btn btn-primary"><i class="fa fa-phone"></i></a>    
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(() => {
            $('#tolak').click(function() {
               tolakZakat();
            });
        });

    async function transAjax(data) {
        html = null;
        data.headers = {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        await $.ajax(data).done(function(res) {
            html = res;
        })
            .fail(function() {
                return false;
            })
        return html
    }

    function tolakZakat(){
        confirmZakat('3');
    }

    async function  confirmZakat(value) {
            var param = {
                method: 'GET',
                url: '<?php echo e(url()->current()); ?>',
                data: {
                    load: 'table',
                    status: value,
                }
            }

            await transAjax(param).then((result) => {
                if(result == '2') {
                    $('#x-message').html('<div class="alert alert-success">Data berhasil dikonfirmasi</div>');
                }else {
                    $('#x-message').html('<div class="alert alert-success">Data berhasil ditolak!</div>');
                }
            }).catch((err) => {
                $('#x-message').html('<div class="alert alert-warning">Internal Server Error!</div>');
        });
    }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/amil/zakat/show.blade.php ENDPATH**/ ?>