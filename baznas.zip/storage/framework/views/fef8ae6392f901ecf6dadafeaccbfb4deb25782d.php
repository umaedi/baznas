
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="container mt-5">
      <div class="page-error">
        <div class="page-inner">
          <div class="page-description">
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <img src="<?php echo e(asset('img/qrcode/qrcode.svg')); ?>" alt="">
                </div>
            </div>
          </div>
        </div>
      </div>
      <div class="simple-footer mt-5">
        Copyright &copy; BAZNAS TUBA <?php echo e(date('Y')); ?>

      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/muzakki/qrcode/index.blade.php ENDPATH**/ ?>