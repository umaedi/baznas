
<?php $__env->startSection('content'); ?>
<div class="main-content container">
    <section class="section">
      <div class="section-header">
        <h1><?php echo e(__("Riwayat Zakat")); ?></h1>
        <div class="section-header-breadcrumb">
          <div class="breadcrumb-item active"><a href="<?php echo e(route('muzakki.dashboard')); ?>">Dashboard</a></div>
          <div class="breadcrumb-item">Riwayat Zakat</div>
        </div>
      </div>
      <div class="card">
        <div class="card-body">
            <div class="section-body">
                <h2 class="section-title">Hi, <?php echo e(auth()->guard('muzakki')->user()->name); ?></h2>
                <p class="section-lead">
                  Ini adalah riwayat pembayaran zakat Anda
                </p>
                <hr>
                <div class="row mb-3">
                    <div class="col-md-6 mb-3">
                        <select class="form-control" id="category" name="category">
                            <option value="">--KATEGORI ZAKAT--</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <select class="form-control" id="perPage" name="pagination">
                            <option value="12">--PER PAGE--</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                  </div>

                <div class="table-responsive" id="x-data-table">
                    
                </div>
              </div>
        </div>
      </div>
 
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>

    var page = 1;
    var paginate = 12;
    var category = '';

    $(() => {
        loadTable();

        $('#category').change(function () {
            filterTable()
        })

        $("#perPage").change(function () {
            filterTable()
        })
    });

    async function transAjax(data) {
        html = null;
        data.headers = {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
        await $.ajax(data).done(function(res) {
            html = res;
        })
            .fail(function() {
                return false;
            })
        return html
    }

    function filterTable() {
        category = $('#category').val();
        paginate = $('#perPage').val();
        loadTable()
    }

    async function loadTable() {
            var param = {
                method: 'GET',
                url: '<?php echo e(url()->current()); ?>',
                data: {
                    load: 'table',
                    category: category,
                    page: page,
                    paginate: paginate,
                }
            }
            // loading(true)
            await transAjax(param).then((result) => {
                // loading(false)
                $('#x-data-table').html(result)

                // initMagnific()
                // checkRow()
            }).catch((err) => {
                console.log('error');
        });
    }

    function loadPaginate(to) {
        page = to
        filterTable()
    }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/muzakki/riwayatzakat/index.blade.php ENDPATH**/ ?>