
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-body text-center">
                <img data-src="<?php echo e(asset('img/success.svg')); ?>" class="lazyload" width="150" alt="">
                <div class="x-text mt-3">
                    <h5>PEMBAYARAN BERHASIL</h5>
                    <p>"Semoga Allah memberikan ganjaran pahala terhadap harta yang telah engkau berikan dan menjadikannya penyuci bagimu, serta semoga Allah memberikan keberkahan hartamu yang masih tersisa padamu."</p>
                </div>
                <a href="<?php echo e(route('muzakki.dashboard')); ?>" class="btn btn-primary">KEMBALI</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.2.2/lazysizes.min.js" async=""></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/muzakki/payment/index.blade.php ENDPATH**/ ?>