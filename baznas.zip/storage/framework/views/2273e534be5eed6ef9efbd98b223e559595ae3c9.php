
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
      <div class="section-header">
        <h1>Invoice</h1>
        <div class="section-header-breadcrumb">
          <div class="breadcrumb-item active"><a href="<?php echo e(route('muzakki.dashboard')); ?>">Dashboard</a></div>
          <div class="breadcrumb-item">Invoice</div>
        </div>
      </div>

      <div class="section-body">
        <div class="invoice">
          <div class="invoice-print">
            <div class="row">
              <div class="col-lg-12">
                <div class="invoice-title">
                  <h2>Invoice</h2>
                </div>
                <hr>

                  <div class="form-row">
                      <div class="form-group col-md-6">
                          <label for="name">Nama Lengkap</label>
                          <input type="text" class="form-control" id="name" value="<?php echo e($invoice->muzakki->name); ?>" readonly/>
                      </div>
                      <div class="form-group col-md-6">
                          <label for="email">Email</label>
                          <input type="email" class="form-control" id="email" value="<?php echo e($invoice->muzakki->email); ?>" readonly/>
                      </div>
                  </div>
                  <div class="form-row">
                      <div class="form-group col-md-6">
                          <label for="name">No HP</label>
                          <input type="text" class="form-control"  id="name" value="<?php echo e($invoice->muzakki->no_tlp); ?>" readonly/>
                      </div>
                      <div class="form-group col-md-6">
                          <label for="email">Status</label>
                          <input type="email" class="form-control" id="email" value="<?php echo e($invoice->muzakki->dinas->nama_dinas); ?>" readonly/>
                      </div>
                  </div>
                  <div class="form-row">
                      <div class="form-group col-md-6">
                          <label for="name">Jumlah/Nominal</label>
                          <input type="text" name="nominal" class="form-control" value="<?php echo e($invoice->nominal); ?>" readonly/>
                      </div>
                      <div class="form-group col-md-6">
                          <label for="inputState">ZIS(Zakat, Infaq, Shodaqoh)</label>
                          <input type="email" class="form-control" id="email" value="<?php echo e($invoice->category->nama_kategori); ?>" readonly/>
                      </div>
                  </div>
                  <a href="<?php echo e(route('muzakki.dashboard')); ?>" class="btn btn-primary btn-icon icon-left"><i class="fa fa-arrow-left"></i></a>
                  <button id="pay-button" class="btn btn-primary btn-icon icon-left"><i class="fas fa-credit-card"></i> Bayar Sekarang</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('midtrans.client_key')); ?>"></script>
    <script>
        const payButton = document.querySelector('#pay-button');
        payButton.addEventListener('click', function(e) {
            e.preventDefault();
 
            snap.pay('<?php echo e(request('snapToken')); ?>', {
                // Optional
                onSuccess: function(result) {
                    /* You may add your own js here, this is just example */
                    // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                    console.log(result)
                },
                // Optional
                onPending: function(result) {
                    /* You may add your own js here, this is just example */
                    // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                    console.log(result)
                },
                // Optional
                onError: function(result) {
                    /* You may add your own js here, this is just example */
                    // document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
                    console.log(result)
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/muzakki/invoice/index.blade.php ENDPATH**/ ?>