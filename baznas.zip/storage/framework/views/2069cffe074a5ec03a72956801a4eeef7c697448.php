<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar container">
  <ul class="navbar-nav navbar-right ml-auto">
      <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user mr-auto">
        <?php if(auth()->user()): ?>
        <img alt="image" src="<?php echo e(asset('storage')); ?>/image/profille/<?php echo e(auth()->user()->image); ?>" class="rounded-circle mr-1">
        <?php else: ?>
        <img alt="image" src="<?php echo e(asset('storage')); ?>/image/profille/<?php echo e(auth()->guard('muzakki')->user()->image ?? auth()->user()->image); ?>" class="rounded-circle mr-1">
        <?php endif; ?>
      <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(auth()->guard('muzakki')->user()->name ?? auth()->user()->name); ?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
        <?php if(auth()->user()): ?>
        <a href="<?php echo e(route('amil.profile')); ?>" class="dropdown-item has-icon">
          <i class="far fa-user"></i> Profile
        </a>
        <?php else: ?>
        <a href="<?php echo e(route('muzakki.profile')); ?>" class="dropdown-item has-icon">
          <i class="far fa-user"></i> Profile
        </a>
        <?php endif; ?>
     
        <div class="dropdown-divider"></div>
        <a href="javascript:void(0)" class="dropdown-item has-icon text-danger" onclick="logOut()">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
    </li>
  </ul>
</nav><?php /**PATH D:\WEB PROGRAMMER\PROJECTS\2023\baznas\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>