<footer class="main-footer container">
  <div class="text-center mb-3">
    Developed by <a href="https://api.whatsapp.com/send?phone=6285741492045" target="_blank">Umaedi KH</a>. Copyright &copy; 2023 Diskominfo Tuba
  </div>
</footer>